import  { ShoppingCart } from './component/ShoppingCart.jsx';
import './App.css'

const App = () => {
  return (  
    <div className="Home">
      <div className="Container">
          <ShoppingCart />
      </div>
    </div>
  );
}

export default App;